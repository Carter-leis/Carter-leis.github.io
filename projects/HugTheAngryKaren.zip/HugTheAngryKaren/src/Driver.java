
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Board bd = new Board(1, 100);
		

	}

}
