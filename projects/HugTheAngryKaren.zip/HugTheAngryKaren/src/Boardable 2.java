
public interface Boardable {

	public boolean isVisible();
}
