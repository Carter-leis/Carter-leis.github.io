
public class TestDriver {

	public static void main(String[] args) {
		Board bd = new Board(3, 5);
		bd.printBoard();

	}

}
